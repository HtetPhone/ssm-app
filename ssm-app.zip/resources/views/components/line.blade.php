<div {{ $attributes(['class' => 'w-48 h-[2px] bg-white rounded-xl']) }}></div>

