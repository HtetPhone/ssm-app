<h1 class="font-amsterdam text-2xl"> {{ $slot }} </h1>
<x-line/>
