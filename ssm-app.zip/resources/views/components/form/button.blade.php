<button {{ $attributes(['class' => "text-lg font-bold px-6 py-1 rounded-full bg-white border-2 border-transparent hover:bg-emerald-400 hover:text-white hover:border-white"]) }}>
    {{ $slot }}
</button>
