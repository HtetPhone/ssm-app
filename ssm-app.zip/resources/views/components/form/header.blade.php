
<h1 {{ $attributes(['class' => "text-white text-2xl font-bold"]) }}> {{ $slot }} </h1>


