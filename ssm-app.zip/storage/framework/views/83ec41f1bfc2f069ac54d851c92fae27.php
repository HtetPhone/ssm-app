<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['active' => false, 'link']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['active' => false, 'link']); ?>
<?php foreach (array_filter((['active' => false, 'link']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($active == true): ?>
    <a class="inline-block rounded-xl px-4 py-1 bg-white text-emerald-400 text-lg">
        <?php echo e($slot); ?>

    </a>
<?php else: ?>
    <a href="<?php echo e($link); ?>" class="inline-block rounded-xl px-4 py-1 hover:bg-white hover:text-emerald-400 text-lg">
        <?php echo e($slot); ?>

    </a>
<?php endif; ?>

<?php /**PATH C:\Users\Admin\Desktop\Lara Projects\ssm-app\resources\views/components/admin/nav-link.blade.php ENDPATH**/ ?>