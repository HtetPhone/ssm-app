<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['payment']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['payment']); ?>
<?php foreach (array_filter((['payment']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="bg-white rounded-xl p-3 md:p-5 flex justify-start items-start border-2 border-transparent hover:border-black">
    <div class="shrink-0">
        <img src="<?php echo e($payment->paymentLogo()); ?>" class="rounded-xl shadow-lg w-[80px] h-[80px]" alt="">
    </div>
    <div class="ms-4 text-wrap md:text-nowrap">
        <p class="md:text-xl font-bold"><?php echo e($payment->acc_no); ?></p>
        <p class="md:text-md text-gray-600 font-bold mt-2"> <?php echo e($payment->acc_name); ?> </p>
    </div>
    <div class="ms-auto flex flex-col space-y-3">
            <a class="w-[30px] p-[1px] rounded-full hover:bg-orange-400" href="<?php echo e(route('payment.detail', $payment)); ?>">
                <img src="<?php echo e(Vite::asset('resources/images/detail.svg')); ?>" alt="detail">
            </a>
            <a class="w-[30px] p-[1px] rounded-xl bg-emerald-400 hover:bg-emerald-400/50" href="<?php echo e(route('payment.edit', $payment)); ?>">
                <img  src="<?php echo e(Vite::asset('resources/images/edit.svg')); ?>" alt="edit">
            </a>


            <form id="delForm" method="POST"  action="<?php echo e(route('payment.delete', $payment)); ?>" >
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button id="delBtn">
                    <img class="w-[30px] p-[1px] rounded-xl bg-rose-400 hover:bg-rose-400/50 mt-auto" src="<?php echo e(Vite::asset('resources/images/delete.svg')); ?>" alt="delete">
                </button>
            </form>
        </div>
    </div>
<?php /**PATH C:\Users\Admin\Desktop\Lara Projects\ssm-app\resources\views/components/admin/card.blade.php ENDPATH**/ ?>