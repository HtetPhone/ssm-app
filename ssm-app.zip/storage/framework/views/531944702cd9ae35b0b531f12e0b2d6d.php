<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['link', 'img']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['link', 'img']); ?>
<?php foreach (array_filter((['link', 'img']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<a <?php echo e($attributes(['class' => "inline-block max-w-[40px]"])); ?> href="<?php echo e($link); ?>">
    <img src="<?php echo e(Vite::asset('resources/images/' . $img)); ?>" alt="<?php echo e($img); ?>">
</a>
<?php /**PATH C:\Users\Admin\Desktop\Lara Projects\ssm-app\resources\views/components/social-link.blade.php ENDPATH**/ ?>