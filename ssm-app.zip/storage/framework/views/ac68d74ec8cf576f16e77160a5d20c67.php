<h1 class="font-amsterdam text-2xl"> <?php echo e($slot); ?> </h1>
<?php if (isset($component)) { $__componentOriginal62ba109e11f054bd71d2d0fe64c4cca4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62ba109e11f054bd71d2d0fe64c4cca4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.line','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('line'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62ba109e11f054bd71d2d0fe64c4cca4)): ?>
<?php $attributes = $__attributesOriginal62ba109e11f054bd71d2d0fe64c4cca4; ?>
<?php unset($__attributesOriginal62ba109e11f054bd71d2d0fe64c4cca4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62ba109e11f054bd71d2d0fe64c4cca4)): ?>
<?php $component = $__componentOriginal62ba109e11f054bd71d2d0fe64c4cca4; ?>
<?php unset($__componentOriginal62ba109e11f054bd71d2d0fe64c4cca4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Admin\Desktop\Lara Projects\ssm-app\resources\views/components/admin/header.blade.php ENDPATH**/ ?>