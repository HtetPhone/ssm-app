<div <?php echo e($attributes(['class' => 'w-48 h-[2px] bg-white rounded-xl'])); ?>></div>

<?php /**PATH C:\Users\Admin\Desktop\Lara Projects\ssm-app\resources\views/components/line.blade.php ENDPATH**/ ?>