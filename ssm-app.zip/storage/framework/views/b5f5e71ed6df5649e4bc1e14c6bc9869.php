
<h1 <?php echo e($attributes(['class' => "text-white text-2xl font-bold"])); ?>> <?php echo e($slot); ?> </h1>


<?php /**PATH C:\Users\Admin\Desktop\Lara Projects\ssm-app\resources\views/components/form/header.blade.php ENDPATH**/ ?>