<?php if (isset($component)) { $__componentOriginal7651faf8e4a1e278424aad70c82de3ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7651faf8e4a1e278424aad70c82de3ba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mb-5">
        <a class="bg-white text-black font-amsterdam px-4 p-1 rounded-lg" href="<?php echo e(route('payment.method')); ?>">Home</a>
    </div>
    <?php if (isset($component)) { $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> Payment Details  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $attributes = $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $component = $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>

    <div class="font-josefin bg-white/50 rounded-xl p-5 md:p-8 my-10 text-black md:w-[70%] ">
        <div class="space-y-8">
            <div class="flex items-start justify-between">
                <img src="<?php echo e($payment->paymentLogo()); ?>" alt="logo" class="w-[200px] md:w-[230px] lg:w-[250px] xl:w-[300px] rounded-xl">
                <div class="flex space-x-4">
                    <a href="<?php echo e(route('payment.edit', $payment)); ?>">
                        <img class="w-[30px] p-[1px] rounded-xl bg-emerald-400 hover:bg-emerald-400/50" src="<?php echo e(Vite::asset('resources/images/edit.svg')); ?>" alt="">
                    </a>


                    <form id="delForm" method="post" action="<?php echo e(route('payment.delete', $payment)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button id="delBtn">
                            <img class="w-[30px] p-[1px] rounded-xl bg-rose-400 hover:bg-rose-400/50 mt-auto" src="<?php echo e(Vite::asset('resources/images/delete.svg')); ?>" alt="">
                        </button>
                    </form>
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginale967c3c4741392f66eb75c220a8a0579 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale967c3c4741392f66eb75c220a8a0579 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.detail-roll','data' => ['label' => 'Payment Name','value' => $payment->payment_name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.detail-roll'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Payment Name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($payment->payment_name)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale967c3c4741392f66eb75c220a8a0579)): ?>
<?php $attributes = $__attributesOriginale967c3c4741392f66eb75c220a8a0579; ?>
<?php unset($__attributesOriginale967c3c4741392f66eb75c220a8a0579); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale967c3c4741392f66eb75c220a8a0579)): ?>
<?php $component = $__componentOriginale967c3c4741392f66eb75c220a8a0579; ?>
<?php unset($__componentOriginale967c3c4741392f66eb75c220a8a0579); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale967c3c4741392f66eb75c220a8a0579 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale967c3c4741392f66eb75c220a8a0579 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.detail-roll','data' => ['label' => 'Account Name','value' => $payment->acc_name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.detail-roll'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Account Name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($payment->acc_name)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale967c3c4741392f66eb75c220a8a0579)): ?>
<?php $attributes = $__attributesOriginale967c3c4741392f66eb75c220a8a0579; ?>
<?php unset($__attributesOriginale967c3c4741392f66eb75c220a8a0579); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale967c3c4741392f66eb75c220a8a0579)): ?>
<?php $component = $__componentOriginale967c3c4741392f66eb75c220a8a0579; ?>
<?php unset($__componentOriginale967c3c4741392f66eb75c220a8a0579); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginale967c3c4741392f66eb75c220a8a0579 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale967c3c4741392f66eb75c220a8a0579 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.detail-roll','data' => ['label' => 'Account Number','value' => $payment->acc_no]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.detail-roll'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Account Number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($payment->acc_no)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale967c3c4741392f66eb75c220a8a0579)): ?>
<?php $attributes = $__attributesOriginale967c3c4741392f66eb75c220a8a0579; ?>
<?php unset($__attributesOriginale967c3c4741392f66eb75c220a8a0579); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale967c3c4741392f66eb75c220a8a0579)): ?>
<?php $component = $__componentOriginale967c3c4741392f66eb75c220a8a0579; ?>
<?php unset($__componentOriginale967c3c4741392f66eb75c220a8a0579); ?>
<?php endif; ?>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/delete-payment.js'); ?>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7651faf8e4a1e278424aad70c82de3ba)): ?>
<?php $attributes = $__attributesOriginal7651faf8e4a1e278424aad70c82de3ba; ?>
<?php unset($__attributesOriginal7651faf8e4a1e278424aad70c82de3ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7651faf8e4a1e278424aad70c82de3ba)): ?>
<?php $component = $__componentOriginal7651faf8e4a1e278424aad70c82de3ba; ?>
<?php unset($__componentOriginal7651faf8e4a1e278424aad70c82de3ba); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Admin\Desktop\Lara Projects\ssm-app\resources\views/admin/details.blade.php ENDPATH**/ ?>